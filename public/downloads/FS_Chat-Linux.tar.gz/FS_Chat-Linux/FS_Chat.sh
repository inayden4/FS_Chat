#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

CONFIG_FILE="$HOME/.config/fs_chat/browser_config.json"
LOCAL_CONFIG="$DIR/browser_config.json"
BROWSER="auto"

if [ -f "$LOCAL_CONFIG" ]; then
  BROWSER=$(grep -o '"browser": *"[^"]*"' "$LOCAL_CONFIG" | cut -d'"' -f4)
elif [ -f "$CONFIG_FILE" ]; then
  BROWSER=$(grep -o '"browser": *"[^"]*"' "$CONFIG_FILE" | cut -d'"' -f4)
fi

PORT=3355
while netstat -tuln 2>/dev/null | grep -q ":$PORT " ; do
  PORT=$((PORT + 1))
done

if command -v node >/dev/null 2>&1; then
  node "$DIR/www/server.cjs" >/dev/null 2>&1 &
  SERVER_PID=$!
elif command -v python3 >/dev/null 2>&1; then
  python3 -m http.server $PORT --directory "$DIR/www" >/dev/null 2>&1 &
  SERVER_PID=$!
else
  python -m SimpleHTTPServer $PORT >/dev/null 2>&1 &
  SERVER_PID=$!
fi

sleep 1
URL="http://127.0.0.1:$PORT/"

if [ "$BROWSER" = "ask" ]; then
  if command -v zenity >/dev/null 2>&1; then
    BROWSER=$(zenity --list --title="FS_Chat - Стартиращ браузър" --column="ID" --column="Браузър" \
      "auto" "Системен браузър по подразбиране" \
      "chrome" "Google Chrome / Chromium" \
      "msedge" "Microsoft Edge" \
      "brave" "Brave Browser" \
      "firefox" "Mozilla Firefox" \
      "opera" "Opera")
  fi
fi

case "$BROWSER" in
  chrome)
    google-chrome --app="$URL" 2>/dev/null || chromium --app="$URL" 2>/dev/null || xdg-open "$URL"
    ;;
  msedge)
    microsoft-edge --app="$URL" 2>/dev/null || xdg-open "$URL"
    ;;
  brave)
    brave-browser --app="$URL" 2>/dev/null || xdg-open "$URL"
    ;;
  firefox)
    firefox -new-window "$URL" 2>/dev/null || xdg-open "$URL"
    ;;
  opera)
    opera "$URL" 2>/dev/null || xdg-open "$URL"
    ;;
  *)
    xdg-open "$URL" 2>/dev/null || sensible-browser "$URL" 2>/dev/null
    ;;
esac

wait $SERVER_PID 2>/dev/null
