var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
  const uploadsDir = import_path.default.join(process.cwd(), "public", "uploads");
  if (!import_fs.default.existsSync(uploadsDir)) {
    import_fs.default.mkdirSync(uploadsDir, { recursive: true });
  }
  app.set("trust proxy", true);
  app.use("/uploads", (_req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    res.header("Cross-Origin-Resource-Policy", "cross-origin");
    next();
  }, import_express.default.static(uploadsDir));
  const avatarsDir = import_path.default.join(process.cwd(), "public", "avatars");
  app.use("/avatars", (_req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    res.header("Cross-Origin-Resource-Policy", "cross-origin");
    next();
  }, import_express.default.static(avatarsDir));
  const downloadsDir = import_path.default.join(process.cwd(), "public", "downloads");
  const sendAttachment = (filePath, filename, res) => {
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    if (filename.endsWith(".exe")) {
      res.setHeader("Content-Type", "application/octet-stream");
    } else if (filename.endsWith(".zip")) {
      res.setHeader("Content-Type", "application/zip");
    } else if (filename.endsWith(".tar.gz")) {
      res.setHeader("Content-Type", "application/gzip");
    }
    return res.sendFile(filePath);
  };
  app.get("/downloads/:filename", (req, res, next) => {
    const filename = import_path.default.basename(req.params.filename);
    const filePath = import_path.default.join(downloadsDir, filename);
    if (import_fs.default.existsSync(filePath)) {
      return sendAttachment(filePath, filename, res);
    }
    next();
  });
  app.get("/api/download/exe", (_req, res) => {
    const filePath = import_path.default.join(downloadsDir, "FS_Chat.exe");
    if (import_fs.default.existsSync(filePath)) {
      return sendAttachment(filePath, "FS_Chat.exe", res);
    }
    res.status(404).send("File not found");
  });
  app.get("/api/download/zip", (_req, res) => {
    const filePath = import_path.default.join(downloadsDir, "FS_Chat-Windows.zip");
    if (import_fs.default.existsSync(filePath)) {
      return sendAttachment(filePath, "FS_Chat-Windows.zip", res);
    }
    res.status(404).send("File not found");
  });
  app.use("/downloads", (_req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    res.header("Cross-Origin-Resource-Policy", "cross-origin");
    next();
  }, import_express.default.static(downloadsDir));
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: Date.now() });
  });
  const getBrowserConfigFile = () => {
    const localAppData = process.env.LOCALAPPDATA || process.env.USERPROFILE || process.env.HOME || process.cwd();
    const appDir = import_path.default.join(localAppData, "FS_Chat");
    if (!import_fs.default.existsSync(appDir)) {
      try {
        import_fs.default.mkdirSync(appDir, { recursive: true });
      } catch (_) {
      }
    }
    return import_path.default.join(appDir, "browser_config.json");
  };
  const getLocalBrowserConfigFile = () => {
    return import_path.default.join(process.cwd(), "browser_config.json");
  };
  app.get("/api/browser-config", (_req, res) => {
    try {
      const primaryFile = getBrowserConfigFile();
      const localFile = getLocalBrowserConfigFile();
      let raw = null;
      if (import_fs.default.existsSync(primaryFile)) {
        raw = import_fs.default.readFileSync(primaryFile, "utf-8");
      } else if (import_fs.default.existsSync(localFile)) {
        raw = import_fs.default.readFileSync(localFile, "utf-8");
      }
      if (raw) {
        const parsed = JSON.parse(raw);
        return res.json({ success: true, config: parsed });
      }
      return res.json({
        success: true,
        config: {
          browser: "auto",
          rememberChoice: true,
          updatedAt: Date.now()
        }
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Error reading config";
      return res.status(500).json({ error: message });
    }
  });
  app.post("/api/browser-config", (req, res) => {
    try {
      const { browser = "auto", rememberChoice = true } = req.body;
      const config = {
        browser,
        rememberChoice: Boolean(rememberChoice),
        updatedAt: Date.now()
      };
      const json = JSON.stringify(config, null, 2);
      try {
        const primaryFile = getBrowserConfigFile();
        import_fs.default.writeFileSync(primaryFile, json, "utf-8");
      } catch (e) {
        console.warn("Could not write primary browser_config:", e);
      }
      try {
        const localFile = getLocalBrowserConfigFile();
        import_fs.default.writeFileSync(localFile, json, "utf-8");
      } catch (e) {
        console.warn("Could not write local browser_config:", e);
      }
      return res.json({ success: true, config });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Error writing config";
      return res.status(500).json({ error: message });
    }
  });
  app.post("/api/upload", (req, res) => {
    try {
      const { fileData, fileName } = req.body;
      if (!fileData) {
        return res.status(400).json({ error: "Missing fileData" });
      }
      let buffer;
      let extension = "jpg";
      if (fileData.startsWith("data:")) {
        const matches = fileData.match(/^data:([A-Za-z0-9-+\/]+);base64,(.+)$/);
        if (matches && matches.length === 3) {
          const mime = matches[1];
          const extFromMime = mime.split("/")[1]?.split(";")[0];
          if (extFromMime) {
            extension = extFromMime === "jpeg" ? "jpg" : extFromMime;
          }
          buffer = Buffer.from(matches[2], "base64");
        } else {
          buffer = Buffer.from(fileData, "base64");
        }
      } else {
        buffer = Buffer.from(fileData, "base64");
      }
      if (fileName && fileName.includes(".")) {
        const ext = fileName.split(".").pop();
        if (ext) extension = ext.toLowerCase();
      }
      const uniqueSuffix = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
      const savedFileName = `media-${uniqueSuffix}.${extension}`;
      const filePath = import_path.default.join(uploadsDir, savedFileName);
      import_fs.default.writeFileSync(filePath, buffer);
      const forwardedHost = req.get("x-forwarded-host");
      const host = forwardedHost || req.get("host") || `localhost:${PORT}`;
      const protoHeader = req.get("x-forwarded-proto");
      const protocol = protoHeader || (req.secure ? "https" : req.protocol || "https");
      const onlineUrl = `${protocol}://${host}/uploads/${savedFileName}`;
      return res.json({
        success: true,
        url: onlineUrl,
        relativePath: `/uploads/${savedFileName}`,
        fileName: savedFileName,
        size: buffer.length
      });
    } catch (err) {
      console.error("Upload error:", err);
      const message = err instanceof Error ? err.message : "Failed to save file";
      return res.status(500).json({ error: message });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
