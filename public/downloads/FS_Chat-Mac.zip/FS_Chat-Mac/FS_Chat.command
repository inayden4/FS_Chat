#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

CONFIG_FILE="$HOME/.config/fs_chat/browser_config.json"
LOCAL_CONFIG="$DIR/browser_config.json"
BROWSER="auto"

if [ -f "$LOCAL_CONFIG" ]; then
  BROWSER=$(grep -o '"browser": *"[^"]*"' "$LOCAL_CONFIG" | cut -d'"' -f4)
elif [ -f "$CONFIG_FILE" ]; then
  BROWSER=$(grep -o '"browser": *"[^"]*"' "$CONFIG_FILE" | cut -d'"' -f4)
fi

PORT=3344
while lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null ; do
  PORT=$((PORT + 1))
done

# Start lightweight webserver
if command -v node >/dev/null 2>&1; then
  node "$DIR/www/server.cjs" >/dev/null 2>&1 &
  SERVER_PID=$!
elif command -v python3 >/dev/null 2>&1; then
  python3 -m http.server $PORT --directory "$DIR/www" >/dev/null 2>&1 &
  SERVER_PID=$!
else
  python -m SimpleHTTPServer $PORT >/dev/null 2>&1 &
  SERVER_PID=$!
fi

sleep 1
URL="http://127.0.0.1:$PORT/"

# Interactive browser selection if "ask"
if [ "$BROWSER" = "ask" ]; then
  CHOICE=$(osascript -e 'try
    choose from list {"Google Chrome", "Microsoft Edge", "Brave Browser", "Firefox", "Opera", "Safari (По подразбиране)"} with title "FS_Chat" with prompt "Изберете браузър за FS_Chat:" OK button name "Стартирай"
  end try')
  case "$CHOICE" in
    *"Chrome"*) BROWSER="chrome" ;;
    *"Edge"*) BROWSER="msedge" ;;
    *"Brave"*) BROWSER="brave" ;;
    *"Firefox"*) BROWSER="firefox" ;;
    *"Opera"*) BROWSER="opera" ;;
    *) BROWSER="auto" ;;
  esac
fi

# Launch browser
case "$BROWSER" in
  chrome)
    open -a "Google Chrome" --args --app="$URL" || open "$URL"
    ;;
  msedge)
    open -a "Microsoft Edge" --args --app="$URL" || open "$URL"
    ;;
  brave)
    open -a "Brave Browser" --args --app="$URL" || open "$URL"
    ;;
  firefox)
    open -a "Firefox" "$URL" || open "$URL"
    ;;
  opera)
    open -a "Opera" "$URL" || open "$URL"
    ;;
  *)
    open "$URL"
    ;;
esac

wait $SERVER_PID 2>/dev/null
